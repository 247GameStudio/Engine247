using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace Engine247.Helper
{
    [Serializable]
    public class SerializedDictionary<TKey, TValue>
    {
        public Dictionary<TKey, TValue> AsDictionary
        {
            get
            {
                Dictionary<TKey, TValue> newDictionary = new Dictionary<TKey, TValue>();
                foreach (var item in _dictionaryList)
                {
                    if (newDictionary.TryAdd(item.Key, item.Value))
                    {
                        continue;
                    }
                    Debug.LogError($"Repeated dictionary key {item.Key} found");
                }
                return newDictionary;
            }
        }
        [SerializeField] private List<SerializedKeyValuePair<TKey, TValue>> _dictionaryList;
    }

    [Serializable]
    public class SerializedKeyValuePair<TKey, TValue>
    {
        [SerializeField] public TKey Key;
        [SerializeField] public TValue Value;
    }
}