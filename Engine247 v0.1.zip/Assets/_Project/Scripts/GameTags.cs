using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class GameTags
    {
        public const string PLAYER = "Player";
        public const string ENEMY = "Enemy";
        public const string PROJECTILE_PLAYER = "ProjectilePlayer";
        public const string PROJECTILE_ENEMY = "ProjectileEnemy";
    }

}