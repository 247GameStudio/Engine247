using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

namespace Engine247
{
    public class HitNumber : MonoBehaviour
    {
        public bool Shake { get => _shake; set => _shake = value; }

        [SerializeField] private float _size = 1;
        [SerializeField] private TMPro.TMP_Text _hitNumberText = null;
        [SerializeField] private Gradient _hitNumberGradient = null;

        private bool _shake = false;

        private void OnEnable()
        {
            transform.localScale = Vector3.zero;
        }
        private void Start()
        {
            if (_shake)
                transform.DOShakePosition(1, .1f, 1000);
            transform.DOScale(Vector3.one * _size, 0.25f)
                .OnComplete(
                () =>
                {
                    transform.DOScale(Vector3.zero, 1f)
                        .OnComplete(
                            () => gameObject.SetActive(false)
                        );
                }
            );
        }

        private void OnDisable()
        {
            Destroy(gameObject);
        }

        public void Setup(int damage)
        {
            _hitNumberText.text = damage.ToString();
            _size = 1 + (damage / 1000f);
            float locationOnGradient = Mathf.Min(damage / 1000f, 1);
            _hitNumberText.color = _hitNumberGradient.Evaluate(locationOnGradient);
        }
        public void Setup(string text, Color color)
        {
            _hitNumberText.text = text;
            _hitNumberText.color = color;
        }
    }

}