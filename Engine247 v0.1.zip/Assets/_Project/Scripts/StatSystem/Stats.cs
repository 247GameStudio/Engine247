using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System;

namespace Engine247
{
    public enum StatType
    {
        MaxHealth,
        LifeRegen,
        MaxMana,
        ManaRegen,
        MaxStamina,
        StaminaRegen,
        MeleeDamage,
        RangedDamage,
        MagicDamage,
        DamageResist,
        MovementSpeed,
        Defense,

    }
    [CreateAssetMenu(fileName = "New Stats Object", menuName = "Engine247/Stats")]
    [Serializable]
    public class Stats : ScriptableObject
    {
        //This class will only store the attributes and a value to them.

        //Steps when adding a new stat
        // - Create the private variable and public getter here.
        // - Create the public getter calculation in StatsController class.
        // - Create the stat entry in the StatType Enum above. 


        /// <summary>
        /// Event for handling the stat variable updates.
        /// Called every time a variable is set.
        /// Should be listened by every script that STORES that variable.
        /// </summary>
        public UnityAction<StatType> OnStatChanged;

        [SerializeField] private float _maxHealth;
        [SerializeField] private float _lifeRegen;
        [SerializeField] private float _maxMana;
        [SerializeField] private float _manaRegen;
        [SerializeField] private float _maxStamina;
        [SerializeField] private float _staminaRegen;
        [SerializeField] private float _meleeDamage;
        [SerializeField] private float _rangedDamage;
        [SerializeField] private float _magicDamage;
        [SerializeField] private float _damageReduction;
        [SerializeField] private float _defense;
        [SerializeField] private float _movementSpeed;

        public float MaxHealth { 
            get => _maxHealth; 
            set 
            { 
                _maxHealth = value;
                OnStatChanged?.Invoke(StatType.MaxHealth);
            }
        }
        public float HealthRegen { 
            get => _lifeRegen;
            set
            {
                _lifeRegen = value;
                OnStatChanged?.Invoke(StatType.LifeRegen);
            } 
        }
        public float MaxMana { 
            get => _maxMana;
            set
            {
                _maxMana = value;
                OnStatChanged?.Invoke(StatType.MaxMana);
            }
        }
        public float ManaRegen { 
            get => _manaRegen; 
            set
            {
                _manaRegen = value;
                OnStatChanged?.Invoke(StatType.ManaRegen);
            }
        }
        public float MaxStamina { 
            get => _maxStamina; 
            set
            {
                _maxStamina = value;
                OnStatChanged?.Invoke(StatType.MaxStamina);
            }
        }
        public float StaminaRegen { 
            get => _staminaRegen;
            set
            {
                _staminaRegen = value;
                OnStatChanged?.Invoke(StatType.StaminaRegen);
            }
        }
        public float MeleeDamage { 
            get => _meleeDamage; 
            set
            {
                _meleeDamage = value;
                OnStatChanged?.Invoke(StatType.MeleeDamage);
            }
        }
        public float RangedDamage { 
            get => _rangedDamage;
            set
            {
                _rangedDamage = value;
                OnStatChanged?.Invoke(StatType.RangedDamage);
            }
        }
        public float MagicDamage { 
            get => _magicDamage;
            set
            {
                _magicDamage = value;
                OnStatChanged?.Invoke(StatType.MagicDamage);
            }
        }
        public float Defense
        {
            get => _defense;
            set
            {
                _defense = value;
                OnStatChanged?.Invoke(StatType.Defense);
            }
        }
        public float DamageReduction { 
            get => _damageReduction; 
            set
            {
                _damageReduction = value;
                OnStatChanged?.Invoke(StatType.DamageResist);
            }
        }
        public float MovementSpeed { 
            get => _movementSpeed;
            set
            {
                _movementSpeed = value;
                OnStatChanged?.Invoke(StatType.MovementSpeed);
            }
        }
    }

}