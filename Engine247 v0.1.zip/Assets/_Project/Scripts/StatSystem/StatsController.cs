using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class StatsController : MonoBehaviour
    {
        public UnityAction<StatType> OnStatChanged;
        public Stats BaseStats => _baseStats;
        /// <summary>
        /// True value added to base stat. If you put 20, it literally means 20.
        /// </summary>
        public Stats BuffsOnBase => _buffsOnBase;
        /// <summary>
        /// The multiplier of the stat. Should be calculated AFTER adding the BuffsOnBase to the BaseStats. Values here mean PERCENTAGE, so you must divide by 100, then multiply.
        /// </summary>
        public Stats BuffsMultipliers => _buffsMultipliers;

        [SerializeField] private Stats _baseStatsData = null;

        [SerializeField] private Stats _buffsOnBaseData = null;

        [SerializeField] private Stats _buffsMultipliersData = null;

        private Stats _baseStats = null;
        private Stats _buffsOnBase = null;
        private Stats _buffsMultipliers = null;

        /// <summary>
        /// Returns: True Value already buffed.
        /// </summary>
        public float MaxHealth
        {
            get
            {
                float baseValue = _baseStats.MaxHealth + _buffsOnBase.MaxHealth;
                float multiplierPercentage = _buffsMultipliers.MaxHealth;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float HealthRegen
        {
            get
            {
                float baseValue = _baseStats.HealthRegen + _buffsOnBase.HealthRegen;
                float multiplierPercentage = _buffsMultipliers.HealthRegen;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float MaxMana
        {
            get
            {
                float baseValue = _baseStats.MaxMana + _buffsOnBase.MaxMana;
                float multiplierPercentage = _buffsMultipliers.MaxMana;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float ManaRegen
        {
            get
            {
                float baseValue = _baseStats.ManaRegen + _buffsOnBase.ManaRegen;
                float multiplierPercentage = _buffsMultipliers.ManaRegen;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float MaxStamina
        {
            get
            {
                float baseValue = _baseStats.MaxStamina + _buffsOnBase.MaxStamina;
                float multiplierPercentage = _buffsMultipliers.MaxStamina;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float StaminaRegen
        {
            get
            {
                float baseValue = _baseStats.StaminaRegen + _buffsOnBase.StaminaRegen;
                float multiplierPercentage = _buffsMultipliers.StaminaRegen;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float MeleeDamage
        {
            get
            {
                float baseValue = _baseStats.MeleeDamage + _buffsOnBase.MeleeDamage;
                float multiplierPercentage = _buffsMultipliers.MeleeDamage;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float RangedDamage
        {
            get
            {
                float baseValue = _baseStats.RangedDamage + _buffsOnBase.RangedDamage;
                float multiplierPercentage = _buffsMultipliers.RangedDamage;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float MagicDamage
        {
            get
            {
                float baseValue = _baseStats.MagicDamage + _buffsOnBase.MagicDamage;
                float multiplierPercentage = _buffsMultipliers.MagicDamage;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float DamageReduction
        {
            get
            {
                float baseValue = _baseStats.DamageReduction + _buffsOnBase.DamageReduction;
                float multiplierPercentage = _buffsMultipliers.DamageReduction;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float Defense
        {
            get
            {
                float baseValue = _baseStats.Defense + _buffsOnBase.Defense;
                float multiplierPercentage = _buffsMultipliers.Defense;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }
        public float MovementSpeed
        {
            get
            {
                float baseValue = _baseStats.MovementSpeed + _buffsOnBase.MovementSpeed;
                float multiplierPercentage = _buffsMultipliers.MovementSpeed;
                return baseValue * (1 + (multiplierPercentage / 100f));
            }
        }


        public void Initialize()
        {
            _baseStats = Instantiate(_baseStatsData);
            _buffsOnBase = Instantiate(_buffsOnBaseData);
            _buffsMultipliers = Instantiate(_buffsMultipliersData);

            _baseStats.OnStatChanged += OnStatChangedHandler;
            _buffsOnBase.OnStatChanged += OnStatChangedHandler;
            _buffsMultipliers.OnStatChanged += OnStatChangedHandler;
        }
        public void Deinitialize()
        {
            _baseStats.OnStatChanged -= OnStatChangedHandler;
            _buffsOnBase.OnStatChanged -= OnStatChangedHandler;
            _buffsMultipliers.OnStatChanged -= OnStatChangedHandler;
        }
        private void OnStatChangedHandler(StatType statType)
        {
            OnStatChanged?.Invoke(statType);
        }
    }

}