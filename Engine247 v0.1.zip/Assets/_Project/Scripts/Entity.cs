using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class Entity : MonoBehaviour
    {
        public string EntityID => _entityID;
        public bool Alive => _alive;
        protected bool _alive = true;
        protected string _entityID;

        protected virtual void Awake()
        {
            _entityID = System.Guid.NewGuid().ToString();
        }
    }

}