using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class MeleeWeapon : Weapon
    {
        [SerializeField] private Transform _hitBoxSpawnPlace = null;
        [SerializeField] private Animator _animator = null;

        public override void SetupWeapon(WeaponData weaponData, Entity owner)
        {
            base.SetupWeapon(weaponData, owner);
            if (!(_weaponData is MeleeWeaponData meleeWeaponData))
                return;
            _animator.runtimeAnimatorController = meleeWeaponData.AnimatorController;
        }

        protected override void FixedUpdate()
        {
            base.FixedUpdate();
        }
        protected override void UseWeapon()
        {
            float fireRate = 1 / _weaponData.AttackRate;

            if (Time.time < _lastShot + fireRate)
                return;

            if (_entityStaminaController != null && !_entityStaminaController.TrySpend(_weaponData.StaminaCost))
                return;

            if(_animator != null)
                _animator.SetBool("IsAttacking", true);

            _lastShot = Time.time;
        }
        public virtual void SpawnHitBox()
        {
            if (!(_weaponData is MeleeWeaponData weaponData))
                return;

            float meleeDamageScaled = weaponData.MeleeScaling > 0 ? _entityStatsController.MeleeDamage * (weaponData.MeleeScaling / 100) : 0;
            float rangedDamageScaled = weaponData.RangedScaling > 0 ? _entityStatsController.RangedDamage * (weaponData.RangedScaling / 100) : 0;
            float magicDamageScaled = weaponData.MagicScaling > 0 ? _entityStatsController.MagicDamage * (weaponData.MagicScaling / 100) : 0;

            HitInfo hitInfo = new HitInfo();
            hitInfo.OwnerID = _owner.EntityID;
            hitInfo.HitDamage = weaponData.BaseDamage + meleeDamageScaled + rangedDamageScaled + magicDamageScaled;
            hitInfo.HitKnockback = weaponData.Knockback;
            hitInfo.HitSize = weaponData.HitSize;
            hitInfo.HitCriticalChance = weaponData.CriticalChance;
            hitInfo.HitDuration = weaponData.HitDuration;

            HitBox2D hitBox = Instantiate(weaponData.HitBox2D);
            hitBox.transform.position = _hitBoxSpawnPlace.position;
            hitBox.transform.rotation = _hitBoxSpawnPlace.rotation;
            hitBox.transform.localScale = transform.parent.parent.localScale;
            hitBox.SetupHitbox(hitInfo);

            OnWeaponUsed?.Invoke();
            _animator.SetBool("IsAttacking", false);
        }
    }
}
