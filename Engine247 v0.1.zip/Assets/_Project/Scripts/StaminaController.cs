using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class StaminaController : MonoBehaviour
    {
        public UnityAction OnStaminaUpdated;

        public int MaxStamina { get { return (int)_statsController.MaxStamina; } }

        public float CurrentStamina
        {
            get => _currentStamina;
            set
            {
                _currentStamina = value;
                OnStaminaUpdated?.Invoke();
            }
        }

        [SerializeField] private StatsController _statsController = null;
        [SerializeField] private StaminaBarView _staminaBarView = null;

        [SerializeField] private float _recoveryWaitCooldown = 0;
        /// <summary>
        /// How many times per second the recovery will be processed.
        /// </summary>
        [SerializeField] private float _recoveryProcessRate = 10;
        
        private float _currentStamina = 0;
        private float _lastTimeSpent = 0;

        public void Initialize()
        {
            CurrentStamina = (int)_statsController.MaxStamina;
            _statsController.OnStatChanged += OnStatChangedHandler;

            if(_staminaBarView != null)
                _staminaBarView.Initialize(this);
            
            InvokeRepeating(nameof(ProcessRecovery), 0, 1 / _recoveryProcessRate);
        }

        public void Deinitialize()
        {
            _statsController.OnStatChanged -= OnStatChangedHandler;

            if(_staminaBarView != null)
                _staminaBarView.Deinitialize();

            CancelInvoke(nameof(ProcessRecovery));
        }
        private void ProcessRecovery()
        {
            if (Time.time > _lastTimeSpent + _recoveryWaitCooldown)
            {
                Recover(_statsController.StaminaRegen / _recoveryProcessRate);
            }
        }
        public void Recover(float amount)
        {
            CurrentStamina = Mathf.Min(CurrentStamina + amount, MaxStamina);
        }
        public bool TrySpend(float amount)
        {
            if (amount > CurrentStamina) return false;

            CurrentStamina -= amount;
            _lastTimeSpent = Time.time;
            return true;
        }
        private void OnStatChangedHandler(StatType statType)
        {
            if (statType != StatType.MaxStamina) return;

            OnStaminaUpdated?.Invoke();
        }
    }

}