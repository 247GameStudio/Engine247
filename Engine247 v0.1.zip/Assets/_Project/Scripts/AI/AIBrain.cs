using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBrain : ScriptableObject
{

    public virtual void Pursue()
    {
        //Brain Specific
    }
    public virtual void Attack()
    {
        //Brain Specific
    }
    public virtual void Search()
    {
        //Brain Specific
    }
    public virtual void Flee()
    {
        //Brain Specific
    }
}
