using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Engine247.Helper;

namespace Engine247
{
    [CreateAssetMenu(fileName = "WeaponData", menuName = "Engine247/ItemData/Weapons/New WeaponData")]
    [System.Serializable]
    public class WeaponData : ScriptableObject
    {
        public Weapon WeaponPrefab => _weaponPrefab;
        public Sprite Sprite => _sprite;
        public Vector3 SpritePosition => _spritePosition;
        public int BaseDamage => _baseDamage;
        public float MeleeScaling => _meleeScaling;
        public float RangedScaling => _rangedScaling;
        public float MagicScaling => _magicScaling;
        public float AttackRate => _attackRate;
        public float Knockback => _knockback; 
        public float CriticalChance => _criticalChance;
        public float StaminaCost => _staminaCost;
        public float ManaCost => _manaCost;
        
        [SerializeField] private Weapon _weaponPrefab;
        [SerializeField] private Sprite _sprite = null;
        [SerializeField] private Vector3 _spritePosition;
        [SerializeField] private int _baseDamage = 0;
        [SerializeField] private float _meleeScaling = 0;
        [SerializeField] private float _rangedScaling = 0;
        [SerializeField] private float _magicScaling = 0;
        [SerializeField] private float _attackRate = 0;
        [SerializeField] private float _knockback = 0;
        [SerializeField] private float _criticalChance = 0;
        //[SerializeField] private float _healthCost = 0;  For weapons that will cost life to use (?)
        [SerializeField] private float _staminaCost = 0;
        [SerializeField] private float _manaCost = 0;
    }
}