using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    [CreateAssetMenu(fileName = "RangedWeaponData", menuName = "Engine247/ItemData/Weapons/New RangedWeaponData")]
    [System.Serializable]
    public class RangedWeaponData : WeaponData
    {
        public Vector3 MuzzlePosition => _muzzlePosition;
        public Projectile Projectile => _projectile;
        public int ProjectileAmount => _projectileAmount;
        public int ProjectilePiercing => _projectilePiercing;
        public int MaxMagazineAmmo => _maxMagazineAmmo;
        public int MagazineAmmo { get => _magazineAmmo; set => _magazineAmmo = value; }
        public int TotalAmmo { get => _totalAmmo; set => _totalAmmo = value; }
        public int MaxAmmo => _maxAmmo;
        public float ReloadTime => _reloadTime;
        public float BulletSpeed => _bulletSpeed;
        public int BulletSpread => _bulletSpread;
        public float BulletSize => _bulletSize;
        public float BulletDuration => _bulletDuration;
        public bool LimitedBullets => _limitedBullets;

        [SerializeField] private Vector3 _muzzlePosition;
        [SerializeField] private Projectile _projectile = null;
        [SerializeField] private int _projectilePiercing = 0;
        [SerializeField] private int _projectileAmount;
        [SerializeField] private int _maxMagazineAmmo = 0;
        [SerializeField] private int _magazineAmmo = 0;
        [SerializeField] private int _maxAmmo = 0;
        [SerializeField] private int _totalAmmo = 0;
        [SerializeField] private float _reloadTime = 0;
        [SerializeField] private float _bulletSpeed = 0;
        [SerializeField] private int _bulletSpread = 0;
        [SerializeField] private float _bulletSize = 1.0f;
        [SerializeField] private float _bulletDuration = 1f;
        [SerializeField] private bool _limitedBullets = false;
    }

}