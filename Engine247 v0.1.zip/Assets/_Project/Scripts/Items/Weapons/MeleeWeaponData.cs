using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    [CreateAssetMenu(fileName = "MeleeWeaponData", menuName = "Engine247/ItemData/Weapons/New MeleeWeaponData")]
    [System.Serializable]
    public class MeleeWeaponData : WeaponData
    {
        public RuntimeAnimatorController AnimatorController => _animatorController;
        public HitBox2D HitBox2D => _hitBox;
        public float HitSize => _hitSize;
        public float HitDuration => _hitDuration;

        [SerializeField] private RuntimeAnimatorController _animatorController = null;
        [SerializeField] private HitBox2D _hitBox = null;
        [SerializeField] private float _hitSize = 1f;
        [SerializeField] private float _hitDuration = 0.2f;
    }

}