using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class Weapon : MonoBehaviour
    {
        public UnityAction OnWeaponUsed;
        [SerializeField] protected WeaponData _weaponData = null;
        [SerializeField] protected SpriteRenderer _spriteRenderer = null;
        
        protected Entity _owner = null;
        protected StatsController _entityStatsController = null;
        protected StaminaController _entityStaminaController = null;
        protected bool _isUsing = false;
        protected float _lastShot = -1;

        protected virtual void FixedUpdate()
        {
            
            if(_isUsing)
            {
                UseWeapon();
            }
        }
        protected virtual void OnDestroy()
        {
            _weaponData = null;
        }

        public virtual void SetupWeapon(WeaponData weaponData, Entity owner)
        {
            _owner = owner;
            _entityStatsController = _owner.GetComponent<StatsController>();
            _entityStaminaController = _owner.GetComponent<StaminaController>();
            _weaponData = weaponData;

            if (_weaponData.Sprite != null)
            {
                _spriteRenderer.sprite = _weaponData.Sprite;
            }
            if(_weaponData.SpritePosition != Vector3.zero)
            {
                _spriteRenderer.transform.localPosition = _weaponData.SpritePosition;
            }

        }

        public virtual void SetIsUsing(bool isUsing)
        {
            _isUsing = isUsing;
        }
        protected virtual void UseWeapon()
        {
            //Child weapons should handle their own firing.
        }

    }

}