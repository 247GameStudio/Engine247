using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Engine247.Helper;
using System.Linq;

namespace Engine247
{
    [CreateAssetMenu(fileName = "New BuffOnBase Effect", menuName = "Engine247/Effects/BuffOnBase Effect")]
    public class BuffOnBaseEffect : Effect
    {
        [SerializeField] private SerializedDictionary<StatType, float> _buffsOnBaseInspector;

        private Dictionary<StatType, float> _buffsOnBase = null;
        private StatsController _entityStatsController = null;
        public override void Apply(Entity entity)
        {
            base.Apply(entity);
            _buffsOnBase = _buffsOnBaseInspector.AsDictionary;

            _entityStatsController = entity.GetComponent<StatsController>();
            foreach (StatType type in _buffsOnBase.Keys.ToList())
            {
                switch (type)
                {
                    case StatType.MaxHealth:
                        _entityStatsController.BuffsOnBase.MaxHealth += _buffsOnBase[type];
                        break;
                    case StatType.LifeRegen:
                        _entityStatsController.BuffsOnBase.HealthRegen += _buffsOnBase[type];
                        break;
                    case StatType.MaxMana:
                        _entityStatsController.BuffsOnBase.MaxMana += _buffsOnBase[type];
                        break;
                    case StatType.ManaRegen:
                        _entityStatsController.BuffsOnBase.ManaRegen += _buffsOnBase[type];
                        break;
                    case StatType.MaxStamina:
                        _entityStatsController.BuffsOnBase.MaxStamina += _buffsOnBase[type];
                        break;
                    case StatType.StaminaRegen:
                        _entityStatsController.BuffsOnBase.StaminaRegen += _buffsOnBase[type];
                        break;
                    case StatType.MeleeDamage:
                        _entityStatsController.BuffsOnBase.MeleeDamage += _buffsOnBase[type];
                        break;
                    case StatType.RangedDamage:
                        _entityStatsController.BuffsOnBase.RangedDamage += _buffsOnBase[type];
                        break;
                    case StatType.MagicDamage:
                        _entityStatsController.BuffsOnBase.MagicDamage += _buffsOnBase[type];
                        break;
                    case StatType.DamageResist:
                        _entityStatsController.BuffsOnBase.DamageReduction += _buffsOnBase[type];
                        break;
                    case StatType.MovementSpeed:
                        _entityStatsController.BuffsOnBase.MovementSpeed += _buffsOnBase[type];
                        break;
                    case StatType.Defense:
                        _entityStatsController.BuffsOnBase.Defense += _buffsOnBase[type];
                        break;
                    default:
                        break;
                }
            }

        }
        public override void Process()
        {
            base.Process();
        }
        public override void Remove()
        {
            base.Remove();

            foreach (StatType type in _buffsOnBase.Keys.ToList())
            {
                switch (type)
                {
                    case StatType.MaxHealth:
                        _entityStatsController.BuffsOnBase.MaxHealth -= _buffsOnBase[type];
                        break;
                    case StatType.LifeRegen:
                        _entityStatsController.BuffsOnBase.HealthRegen -= _buffsOnBase[type];
                        break;
                    case StatType.MaxMana:
                        _entityStatsController.BuffsOnBase.MaxMana -= _buffsOnBase[type];
                        break;
                    case StatType.ManaRegen:
                        _entityStatsController.BuffsOnBase.ManaRegen -= _buffsOnBase[type];
                        break;
                    case StatType.MaxStamina:
                        _entityStatsController.BuffsOnBase.MaxStamina -= _buffsOnBase[type];
                        break;
                    case StatType.StaminaRegen:
                        _entityStatsController.BuffsOnBase.StaminaRegen -= _buffsOnBase[type];
                        break;
                    case StatType.MeleeDamage:
                        _entityStatsController.BuffsOnBase.MeleeDamage -= _buffsOnBase[type];
                        break;
                    case StatType.RangedDamage:
                        _entityStatsController.BuffsOnBase.RangedDamage -= _buffsOnBase[type];
                        break;
                    case StatType.MagicDamage:
                        _entityStatsController.BuffsOnBase.MagicDamage -= _buffsOnBase[type];
                        break;
                    case StatType.DamageResist:
                        _entityStatsController.BuffsOnBase.DamageReduction -= _buffsOnBase[type];
                        break;
                    case StatType.MovementSpeed:
                        _entityStatsController.BuffsOnBase.MovementSpeed -= _buffsOnBase[type];
                        break;
                    case StatType.Defense:
                        _entityStatsController.BuffsOnBase.Defense -= _buffsOnBase[type];
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
