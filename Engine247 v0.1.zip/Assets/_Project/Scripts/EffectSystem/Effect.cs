using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public enum EffectType
    {
        BuffOnBaseIncrease,
        BuffMultiplierIncrease,
    }
    public class Effect : ScriptableObject
    {
        public string EffectID => _effectId;
        public EffectType EffectType => _effectType;
        public bool ShouldRemove => _shouldRemove;

        [SerializeField] private EffectType _effectType;
        [SerializeField] private string _effectId = string.Empty;
        [SerializeField] private float _effectDuration;
        [Tooltip("How many times per second the effect will be proccessed (Max: 10)")]
        [SerializeField] private float _processRate;
        
        private bool _shouldRemove = false;
        private float _startTime = 0;
        public virtual void Apply(Entity entity) 
        {
            _effectId = System.Guid.NewGuid().ToString();
            _startTime = Time.time;
        }
        public virtual void Process() 
        {
            if (Time.time > _startTime + _effectDuration)
                _shouldRemove = true;
        }
        public virtual void Remove() { }
    }
}
