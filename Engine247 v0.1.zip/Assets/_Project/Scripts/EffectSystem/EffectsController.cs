using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace Engine247
{
    public class EffectsController : MonoBehaviour
    {
        [SerializeField] private List<Effect> testEffects = null;
        [SerializeField] private List<Effect> _activeEffects = null;

        private Entity _entity = null;
        public void OnEnable()
        {
            _activeEffects = new List<Effect>();
            _entity = GetComponent<Entity>();
            InvokeRepeating(nameof(ProcessEffects), 0, 0.1f);
        }
        public void Start()
        {
            // REMOVE IN FINAL VERSION \/
            if (testEffects != null)
                foreach (var effect in testEffects)
                {
                    ApplyEffect(effect);
                }
            // REMOVE IN FINAL VERSION /\
        }
        public void ApplyEffect(Effect effect)
        {
            effect.Apply(_entity);
            _activeEffects.Add(effect);
        }
        public void ProcessEffects()
        {
            foreach (Effect e in _activeEffects)
            {
                e.Process();
            }
            _activeEffects.RemoveAll(effect => effect.ShouldRemove);
        }
        public void RemoveEffectsOfType(EffectType effectType)
        {
            List<Effect> effectsOfType = _activeEffects.Where(effect => effect.EffectType == effectType).ToList();
            foreach (Effect e in effectsOfType)
            {
                e.Remove();
            }
            _activeEffects.RemoveAll(effect => effect.EffectType == effectType);
        }
        public void RemoveEffect(string effectId)
        {
            Effect e = _activeEffects.Find(effect => effect.EffectID == effectId);
            e.Remove();
            _activeEffects.Remove(e);
        }
    }
}
