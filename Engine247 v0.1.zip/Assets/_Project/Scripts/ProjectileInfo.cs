using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileInfo
{
    public int BulletDamage => _bulletDamage;
    public int BulletPiercing { get => _bulletPiercing; set => _bulletPiercing = value; }
    public float BulletSpeed => _bulletSpeed;
    public float BulletSpread => _bulletSpread;
    public float BulletKnockback => _bulletKnockback;
    public float BulletSize => _bulletSize;
    public float CriticalChance => _criticalChance;
    public float BulletDuration => _bulletDuration;

    [SerializeField] private int _bulletDamage = 0;
    [SerializeField] private int _bulletPiercing = 0;
    [SerializeField] private float _bulletSpeed = 0;
    [SerializeField] private float _bulletSpread = 0;
    [SerializeField] private float _bulletKnockback = 0;
    [SerializeField] private float _bulletSize = 1.0f;
    [SerializeField] private float _criticalChance = 0;
    [SerializeField] private float _bulletDuration = 1f;

    public ProjectileInfo(int damage, int piercing, float speed, float spread, float knockback, float size, float criticalChance, float bulletDuration)
    {
        _bulletDamage = damage;
        _bulletPiercing = piercing;
        _bulletSpeed = speed;
        _bulletSpread = spread;
        _bulletKnockback = knockback;
        _bulletSize = size;
        _criticalChance = criticalChance;
        _bulletDuration = bulletDuration;
    }
}
