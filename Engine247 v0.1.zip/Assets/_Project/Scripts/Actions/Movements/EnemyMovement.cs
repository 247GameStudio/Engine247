using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class EnemyMovement : Movement
    {
        [SerializeField] private EnemyAiming _enemyAiming = null;
        public Vector2 Target
        {
            get => _target;
            set
            {
                _target = value;
                _enemyAiming.Aim(_target);
            }
        }

        private Vector2 _target = Vector2.zero;

        protected override void FixedUpdate()
        {
            UpdateMovementDirection();
            base.FixedUpdate();
        }
        public void StopMovement()
        {
            _movementDirection = new Vector2(0, -1);
        }
        private void UpdateMovementDirection()
        {
            if(_target == null || _target == Vector2.zero)
            {
                _movementDirection = Vector2.zero;
                return;
            }

            _movementDirection = (_target - (Vector2)transform.position).normalized;

        }
    }

}