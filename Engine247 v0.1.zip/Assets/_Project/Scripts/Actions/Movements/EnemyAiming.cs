using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class EnemyAiming : MonoBehaviour
    {
        [SerializeField] private Transform _weaponHandle = null;

        public void Aim(Vector2 target)
        {
            if (_weaponHandle == null || target == Vector2.zero) return;

            Vector2 aimdirection = target - (Vector2)transform.position;
            _weaponHandle.transform.right = aimdirection.normalized;

            if(Vector3.Dot(aimdirection, transform.right) > 0)
            {
                //Right
                _weaponHandle.transform.localScale = new Vector3(1, 1, 1);
            }
            else
            {
                //Left
                _weaponHandle.transform.localScale = new Vector3(1, -1, 1);
            }
        }
    }
}
