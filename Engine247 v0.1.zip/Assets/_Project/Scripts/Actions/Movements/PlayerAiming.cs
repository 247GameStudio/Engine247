using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Engine247
{
    public class PlayerAiming : MonoBehaviour
    {
        [SerializeField] private Transform _weaponHandle = null;

        private void FixedUpdate()
        {
            Aim();
        }
        public void Aim()
        {
            if (_weaponHandle == null) return;

            Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Mouse.current.position.value);
            Vector2 aimdirection = mousePosition - (Vector2)transform.position;
            _weaponHandle.transform.right = aimdirection.normalized;

            if (Vector3.Dot(aimdirection, transform.right) > 0)
            {
                //Right
                _weaponHandle.transform.localScale = new Vector3(1, 1, 1);
            }
            else
            {
                //Left
                _weaponHandle.transform.localScale = new Vector3(1, -1, 1);
            }
        }
    }

}