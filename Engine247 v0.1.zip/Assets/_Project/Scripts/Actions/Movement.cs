using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class Movement : MonoBehaviour
    {
        protected Vector2 _movementDirection = Vector2.zero;
        protected float _angleToRotate = 0;

        [SerializeField] private Rigidbody2D _rigidbody2D = null;
        [SerializeField] private Entity _entity = null;
        [SerializeField] private StatsController _statsController = null;
        [SerializeField] private Animator _animatorController = null;

        [SerializeField] private float _currentSpeed = 0;
        [SerializeField] private float _acceleration = 2.3f;
        [SerializeField] private float _stoppingPower = 1.2f;
        [SerializeField] private float _rotationSpeed = 0;
        [SerializeField] private float _rotationMaxSpeed = 0;
        [SerializeField] private float _rotationMultiplier = 0;

        protected virtual void FixedUpdate()
        {
            Move();
            if(_currentSpeed > 0f)
            {
                _rigidbody2D.MovePosition(_rigidbody2D.position + _movementDirection * _currentSpeed * Time.fixedDeltaTime);
            }
            if(_angleToRotate > 1 || _angleToRotate < -1)
            {
                float finalRotation = _angleToRotate > 1 ? Mathf.Min(_rotationSpeed * _rotationMultiplier, _rotationMaxSpeed) : Mathf.Max(-_rotationSpeed * _rotationMultiplier, -_rotationMaxSpeed);
                transform.Rotate(transform.forward, finalRotation * Time.deltaTime );
            }

            _rigidbody2D.angularVelocity = 0f;
        }

        private void Accelerate()
        {
            _currentSpeed = Mathf.Lerp(_currentSpeed, _statsController.MovementSpeed, _acceleration * Time.fixedDeltaTime);
        }
        private void Stop()
        {
            _currentSpeed = _currentSpeed > 0.01f ? Mathf.Lerp(_currentSpeed, 0f, _stoppingPower * Time.fixedDeltaTime) : _currentSpeed = 0;
        }

        private void Move()
        {
            if (!_entity.Alive)
            {
                Stop();
                return;
            }
            if(_movementDirection == Vector2.zero)
            {
                if(_animatorController != null)
                {
                    _animatorController.SetBool("IsWalking", false);
                }
                Stop();
                return;
            }

            if (_animatorController != null)
            {
                _animatorController.SetFloat("X", _movementDirection.x);
                _animatorController.SetFloat("Y", _movementDirection.y);
                _animatorController.SetBool("IsWalking", true);
            }

            Accelerate();
        }

    }
}
