using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

namespace Engine247
{
    public class PlayerActions : MonoBehaviour
    {
        public UnityAction<InputActionPhase> OnPrimaryAction;
        public UnityAction<InputActionPhase> OnSecondaryAction;
        public UnityAction<InputActionPhase> OnInteractionAction;
        public UnityAction OnNextWeapon;
        public UnityAction OnPreviousWeapon;

        public void OnPrimaryActionHandler(InputAction.CallbackContext context)
        {
            switch (context.phase)
            {
                case InputActionPhase.Performed:
                    break;
                case InputActionPhase.Canceled:
                    break;
                default:
                    return;
            }

            OnPrimaryAction?.Invoke(context.phase);
        }
        public void OnSecondaryActionHandler(InputAction.CallbackContext context)
        {
            switch (context.phase)
            {
                case InputActionPhase.Performed:
                    break;
                case InputActionPhase.Canceled:
                    break;
                default:
                    return;
            }

            OnSecondaryAction?.Invoke(context.phase);
        }
        public void OnInteractionActionHandler(InputAction.CallbackContext context)
        {
            switch (context.phase)
            {
                case InputActionPhase.Performed:
                    break;
                case InputActionPhase.Canceled:
                    break;
                default:
                    return;
            }

            OnInteractionAction?.Invoke(context.phase);
        }
        public void OnWeaponSwapNext(InputAction.CallbackContext context)
        {
            if (!context.performed) return;
            float scrollDirection = context.ReadValue<float>();
            OnSwap(scrollDirection);
        }
        public void OnWeaponSwapPrevious(InputAction.CallbackContext context)
        {
            if (!context.performed) return;
            float scrollDirection = context.ReadValue<float>();
            OnSwap(scrollDirection);
        }
        public void OnSwap(float direction)
        {
            if (direction > 0)
                OnPreviousWeapon?.Invoke();
            else if (direction < 0)
                OnNextWeapon?.Invoke();
        }
    }
}
