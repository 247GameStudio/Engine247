using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class Shoot : ActionBase
    {
        [SerializeField] private Projectile _projectile = null;

        public override void DoAction()
        {
            Debug.Log("Will shoot projectile here!");
        }
    }
}
