using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class AttackBase : ScriptableObject
    {
        public UnityAction OnAttackCompleted;

        public virtual void Attack(Transform attacker, Transform target)
        {
        }
    }
}