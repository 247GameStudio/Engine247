using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class MeleeAttack : AttackBase
    {

        public override void Attack(Transform attacker, Transform target)
        {
            base.Attack(attacker, target);
        }


    }

}