using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class ActionBase : ScriptableObject
    {
        public virtual void DoAction()
        {
            Debug.LogError("ActionBase.DoAction()");
        }

    }

}