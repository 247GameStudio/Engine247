using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class EnemyWeaponController : MonoBehaviour
    {
        public UnityAction OnWeaponUsed;
        [SerializeField] private EnemyEntity _enemyEntity = null;

        [SerializeField] private List<WeaponData> _testWeapon = null;

        [SerializeField] private List<WeaponData> _weapons = null;
        [SerializeField] private Transform _weaponHandle = null;
        [SerializeField] private ReloadBarView _reloadBarViewPrefab = null;
        [SerializeField] private int _currentWeapon = 0;

        private Weapon _weaponObject = null;
        private ReloadBarView _reloadBarView = null;

        private void OnEnable()
        {
            _weapons = new List<WeaponData>();
            foreach (var wpn in _testWeapon)
            {
                _weapons.Add(Instantiate(wpn));
            }

            Initialize();
        }
        private void OnDisable()
        {
            Deinitialize();
        }
        public void SetIsUsing(bool isUsing)
        {
            _weaponObject.SetIsUsing(isUsing);
        }
        private void Initialize()
        {
            _weaponObject = Instantiate(_weapons[_currentWeapon].WeaponPrefab);
            _weaponObject.transform.SetParent(_weaponHandle, false);
            _weaponObject.SetupWeapon(_weapons[_currentWeapon], _enemyEntity);
            _weaponObject.OnWeaponUsed += OnWeaponUsedHandler;

            if (_weaponObject is RangedWeapon rangedWeaponObject)
            {
                rangedWeaponObject.OnWeaponReload += OnWeaponReloadHandler;
                rangedWeaponObject.OnReloadComplete += OnReloadCompleteHandler;
            }

            _reloadBarView = Instantiate(_reloadBarViewPrefab, transform);
        }
        private void Deinitialize()
        {
            _weaponObject.OnWeaponUsed -= OnWeaponUsedHandler;
            _weaponObject.SetIsUsing(false);

            if (_weaponObject is RangedWeapon rangedWeaponObject)
            {
                rangedWeaponObject.OnWeaponReload -= OnWeaponReloadHandler;
                rangedWeaponObject.OnReloadComplete -= OnReloadCompleteHandler;
            }

            Destroy(_weaponObject.gameObject);
            Destroy(_reloadBarView.gameObject);
        }
        private void RefreshWeapon()
        {
            Deinitialize();
            Initialize();
        }
        
        private void OnWeaponReloadHandler(float timerStart, float reloadTime)
        {
            _reloadBarView.Initialize(timerStart, reloadTime);
        }
        private void OnReloadCompleteHandler()
        {
            _reloadBarView.Deinitialize();
        }
        private void OnNextWeaponHandler()
        {
            _currentWeapon = (_currentWeapon++) % _weapons.Count;

            RefreshWeapon();
        }
        private void OnPreviousWeaponHandler()
        {
            _currentWeapon -= 1;

            if (_currentWeapon < 0)
                _currentWeapon = _weapons.Count - 1;

            RefreshWeapon();
        }
        private void OnWeaponUsedHandler()
        {
            OnWeaponUsed?.Invoke();
        }
    }
}
