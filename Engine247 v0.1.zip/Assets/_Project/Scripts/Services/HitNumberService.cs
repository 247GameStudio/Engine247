using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public enum HitNumberType
    {
        Damage,
        CritDamage,
        Miss,
        Block,
    }
    public class HitNumberService : MonoBehaviour
    {
        public static HitNumberService Instance => _instance;
        private static HitNumberService _instance;

        [SerializeField] private HitNumber _hitNumberPrefab = null;

        private void Awake()
        {
            if(_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }
            _instance = this;
        }

        public HitNumber CreateHitNumber(HitNumberType hitNumberType, int amount = 0)
        {
            HitNumber hitNumber = Instantiate(_hitNumberPrefab);
            switch (hitNumberType)
            {
                case HitNumberType.Damage:
                    hitNumber.Setup(amount);
                    break;
                case HitNumberType.Miss:
                    hitNumber.Setup("Miss", Color.grey);
                    break;
                case HitNumberType.Block:
                    hitNumber.Setup("Block", Color.gray);
                    hitNumber.Shake = true;
                    break;
                case HitNumberType.CritDamage:
                    hitNumber.Setup(amount);
                    hitNumber.Shake = true;
                    break;
                default:
                    break;
            }
            return hitNumber;
        }
    }
}
