using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public interface IDamageable {
        public void TakeDamage(int calculatedIncomingDamage); 
    }
}
