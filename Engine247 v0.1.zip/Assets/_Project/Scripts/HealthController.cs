using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class HealthController : MonoBehaviour
    {
        public UnityAction OnHealthUdpated;
        public UnityAction OnDeath;

        public int MaxHealth { get { return (int)_statsController.MaxHealth; } }

        public float CurrentHealth { get => _currentHealth; 
            set
            {
                _currentHealth = value;
                OnHealthUdpated?.Invoke();
            } 
        }

        [SerializeField] private StatsController _statsController = null;
        [SerializeField] private HealthBarView _healthBarView = null;


        [SerializeField] private float _recoveryWaitCooldown = 0;
        /// <summary>
        /// How many times per second the recovery will be processed.
        /// </summary>
        [SerializeField] private float _recoveryProcessRate = 10;

        private float _currentHealth = 0;
        private float _lastTimeDamaged = 0;

        public void Initialize()
        {
            CurrentHealth = (int)_statsController.MaxHealth;
            _statsController.OnStatChanged += OnStatChangedHandler;
            
            _healthBarView.Initialize(this);

            InvokeRepeating(nameof(ProcessRecovery), 0, 1 / _recoveryProcessRate);
        }
        public void Deinitialize()
        {
            _statsController.OnStatChanged -= OnStatChangedHandler;

            if(_healthBarView != null)
                _healthBarView.Deinitialize();

            CancelInvoke(nameof(ProcessRecovery));
        }
        private void ProcessRecovery()
        {
            if (Time.time > _lastTimeDamaged + _recoveryWaitCooldown)
            {
                Heal(_statsController.HealthRegen / _recoveryProcessRate);
            }
        }
        public void Heal(float healing)
        {
            CurrentHealth = Mathf.Min(CurrentHealth + healing, MaxHealth);
        }
        public void Damage(int damage)
        {
            CurrentHealth = Mathf.Max(CurrentHealth - damage, 0);
            _lastTimeDamaged = Time.time;
            Debug.Log($"Entity {gameObject.name} took {damage} points of damage!");
            if (CurrentHealth <= 0)
            {
                OnDeath?.Invoke();
            }
        }
        private void OnStatChangedHandler(StatType statType)
        {
            if (statType != StatType.MaxHealth) return;

            OnHealthUdpated?.Invoke();
        }
    }

}