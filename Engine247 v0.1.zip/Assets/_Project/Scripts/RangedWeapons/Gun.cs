using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class Gun : RangedWeapon
    {
        
    }
}
