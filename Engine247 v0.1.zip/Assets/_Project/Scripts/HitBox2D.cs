using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class HitInfo
    {
        public string OwnerID;
        public float HitDamage;
        public float HitSize;
        public float HitCriticalChance;
        public float HitKnockback;
        public float HitDuration;
    }
    public class HitBox2D : MonoBehaviour
    {
        private HitInfo _hitInfo = null;
        private float _hitDuration = 0.2f;
        
        private void Start()
        {
            Destroy(gameObject, _hitDuration);
        }
        public void SetupHitbox(HitInfo hitInfo)
        {
            _hitInfo = hitInfo;
            transform.localScale *= _hitInfo.HitSize;
            _hitDuration = hitInfo.HitDuration;
        }
        private void OnTriggerEnter2D(Collider2D collision)
        {
            Entity entity = collision.GetComponent<Entity>();

            if (entity == null || entity.EntityID == _hitInfo.OwnerID) return;

            bool isCrit = false;
            if (Random.Range(0, 100) < _hitInfo.HitCriticalChance)
            {
                isCrit = true;
            }

            float hitDamage = isCrit ? _hitInfo.HitDamage * 2 : _hitInfo.HitDamage * 1;

            float variatedDamage = hitDamage * Random.Range(0.85f, 1.15f);

            int finalDamage = Mathf.CeilToInt(Mathf.Max(variatedDamage, 1));

            HitNumberType hitNumberType = isCrit ? HitNumberType.CritDamage : HitNumberType.Damage;
            HitNumber hitNumber = HitNumberService.Instance.CreateHitNumber(hitNumberType, finalDamage);
            hitNumber.transform.position = collision.transform.position;

            collision.GetComponent<IDamageable>().TakeDamage(finalDamage);
        }
    }

}