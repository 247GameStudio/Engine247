using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Engine247
{
    public class PlayerWeaponController : MonoBehaviour
    {
        [SerializeField] private PlayerEntity _playerEntity = null;
        [SerializeField] private PlayerActions _playerActions = null;

        [SerializeField] private List<WeaponData> _testWeapon = null;

        [SerializeField] private List<WeaponData> _weapons = null;
        [SerializeField] private Transform _weaponHandle = null;
        [SerializeField] private ReloadBarView _reloadBarViewPrefab = null;
        [SerializeField] private int _currentWeapon = 0;

        private Weapon _weaponObject = null;
        private ReloadBarView _reloadBarView = null;

        private void OnEnable()
        {
            _weapons = new List<WeaponData>();
            foreach (var wpn in _testWeapon)
            {
                _weapons.Add(Instantiate(wpn));
            }

            Initialize();
        }
        private void OnDisable()
        {
            Deinitialize();
        }

        private void Initialize()
        {
            _weaponObject = Instantiate(_weapons[_currentWeapon].WeaponPrefab);
            _weaponObject.transform.SetParent(_weaponHandle, false);
            _weaponObject.SetupWeapon(_weapons[_currentWeapon], _playerEntity);
            
            if(_weaponObject is RangedWeapon rangedWeaponObject)
            {
                rangedWeaponObject.OnWeaponReload += OnWeaponReloadHandler;
                rangedWeaponObject.OnReloadComplete += OnReloadCompleteHandler;
            }

            _reloadBarView = Instantiate(_reloadBarViewPrefab, transform);
            
            _playerActions.OnPrimaryAction += OnPrimaryActionHandler;
            _playerActions.OnNextWeapon += OnNextWeaponHandler;
            _playerActions.OnPreviousWeapon += OnPreviousWeaponHandler;
        }
        private void Deinitialize()
        {
            if (_weaponObject is RangedWeapon rangedWeaponObject)
            {
                rangedWeaponObject.OnWeaponReload -= OnWeaponReloadHandler;
                rangedWeaponObject.OnReloadComplete -= OnReloadCompleteHandler;
            }

            Destroy(_weaponObject.gameObject);

            Destroy(_reloadBarView.gameObject);

            _playerActions.OnPrimaryAction -= OnPrimaryActionHandler;
            _playerActions.OnNextWeapon -= OnNextWeaponHandler;
            _playerActions.OnPreviousWeapon -= OnPreviousWeaponHandler;
        }
        private void RefreshWeapon()
        {
            Deinitialize();
            Initialize();
        }
        private void OnWeaponReloadHandler(float timerStart, float reloadTime)
        {
            _reloadBarView.Initialize(timerStart, reloadTime);
        }
        private void OnReloadCompleteHandler()
        {
            _reloadBarView.Deinitialize();
        }
        private void OnNextWeaponHandler()
        {
            _currentWeapon = (_currentWeapon++) % _weapons.Count;
            
            RefreshWeapon();
        }
        private void OnPreviousWeaponHandler()
        {
            _currentWeapon -= 1;
            
            if (_currentWeapon < 0)
                _currentWeapon = _weapons.Count - 1;
            
            RefreshWeapon();
        }
        private void OnPrimaryActionHandler(InputActionPhase phase)
        {
            switch (phase)
            {
                case InputActionPhase.Performed:
                    _weaponObject.SetIsUsing(true);
                    break;
                case InputActionPhase.Canceled:
                    _weaponObject.SetIsUsing(false);
                    break;
                default:
                    return;
            }
        }
    }
}
