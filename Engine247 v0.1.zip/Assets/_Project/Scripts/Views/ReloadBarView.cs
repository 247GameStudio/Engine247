using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReloadBarView : MonoBehaviour
{
    [SerializeField] private Slider _reloadBar = null;

    private void Update()
    {
        _reloadBar.value = Time.time;
    }
    public void Initialize(float startTime, float reloadTime)
    {
        _reloadBar.gameObject.SetActive(true);
        _reloadBar.minValue = startTime;
        _reloadBar.maxValue = startTime + reloadTime;
    }
    public void Deinitialize()
    {
        _reloadBar.gameObject.SetActive(false);
    }
}
