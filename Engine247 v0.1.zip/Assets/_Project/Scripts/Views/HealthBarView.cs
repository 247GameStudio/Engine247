using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

namespace Engine247
{
    public class HealthBarView : MonoBehaviour
    {
        [SerializeField] private Slider _healthBarSlider = null;
        [SerializeField] private Slider _healthBarBackSlider = null;
        
        private HealthController _healthController = null;
        private RectTransform _rectTransform = null;
        
        //The Size in pixels per points of stat
        [SerializeField] private float _rectSizeMultiplier = 2f;

        private string tweenID = "health";

        public void Start()
        {
            tweenID += gameObject.GetInstanceID();
            _rectTransform = GetComponent<RectTransform>();
            _healthBarSlider.maxValue = _healthController.MaxHealth;
            _healthBarSlider.value = _healthController.CurrentHealth;
            _healthBarBackSlider.maxValue = _healthController.MaxHealth;
            _healthBarBackSlider.value = _healthController.CurrentHealth;
        }
        public void Initialize(HealthController healthController)
        {
            _healthController = healthController;
            _healthBarSlider.maxValue = _healthController.MaxHealth;
            _healthBarSlider.minValue = 0;
            _healthController.OnHealthUdpated += OnHealthUpdatedHandler;
        }
        public void Deinitialize()
        {
            _healthController.OnHealthUdpated -= OnHealthUpdatedHandler;
        }

        public void OnHealthUpdatedHandler()
        {
            _rectTransform.sizeDelta = new Vector2(_rectSizeMultiplier * _healthController.MaxHealth, 3f);
            _healthBarSlider.maxValue = _healthController.MaxHealth;
            
            if (_healthBarSlider.value > _healthController.CurrentHealth)
            {
                _healthBarSlider.value = _healthController.CurrentHealth;
                List<Tween> activeTweens = DOTween.TweensById(tweenID);
                if (activeTweens != null && activeTweens.Count > 0)
                {
                    DOTween.Restart(tweenID, true, 0);
                }
                else
                {
                    Sequence sequence = DOTween.Sequence();
                    sequence.SetId(tweenID);
                    sequence.SetDelay(0.3f);
                    sequence.Append(_healthBarBackSlider.DOValue(_healthController.CurrentHealth, .25f));
                }
            }
            else
            {
                _healthBarSlider.value = _healthController.CurrentHealth;

                if (_healthBarBackSlider.value < _healthController.CurrentHealth)
                    _healthBarBackSlider.value = _healthController.CurrentHealth;
            }

        }
    }
}
