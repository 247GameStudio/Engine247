using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class RangedWeapon : Weapon
    {
        public UnityAction<float, float> OnWeaponReload;
        public UnityAction OnReloadComplete;

        [SerializeField] private Transform _muzzle = null;
        private bool _reloading = false;
        private float _reloadStart = 0;

        protected override void FixedUpdate()
        {
            if (_reloading)
            {
                ProcessReload();
                return;
            }
            base.FixedUpdate();
        }
        public override void SetupWeapon(WeaponData weaponData, Entity owner)
        {
            if (!(weaponData is RangedWeaponData rangedWeaponData))
                return;

            base.SetupWeapon(rangedWeaponData, owner); 
            if (rangedWeaponData.MuzzlePosition != Vector3.zero)
            {
                _muzzle.transform.localPosition = rangedWeaponData.MuzzlePosition;
            }
        }
        protected override void UseWeapon()
        {
            if (!(_weaponData is RangedWeaponData rangedWeaponData))
                return;

            float fireRate = 1 / rangedWeaponData.AttackRate;

            if (Time.time < _lastShot + fireRate)
            {
                return;
            }

            if (rangedWeaponData.MagazineAmmo <= 0)
            {
                ReloadWeapon();
                return;
            }

            float meleeDamageScaled = rangedWeaponData.MeleeScaling > 0 ? _entityStatsController.MeleeDamage * (rangedWeaponData.MeleeScaling / 100) : 0;
            float rangedDamageScaled = rangedWeaponData.RangedScaling > 0 ? _entityStatsController.RangedDamage * (rangedWeaponData.RangedScaling / 100) : 0;
            float magicDamageScaled = rangedWeaponData.MagicScaling > 0 ? _entityStatsController.MagicDamage * (rangedWeaponData.MagicScaling / 100) : 0;
            
            int projectileDamage = Mathf.CeilToInt(rangedWeaponData.BaseDamage + meleeDamageScaled + rangedDamageScaled + magicDamageScaled);
            int projectilePiercing = rangedWeaponData.ProjectilePiercing;
            float projectileSpeed = rangedWeaponData.BulletSpeed;
            float projectileSpread = rangedWeaponData.BulletSpread;
            float projectileKnockback = rangedWeaponData.Knockback;
            float projectileSize = rangedWeaponData.BulletSize;
            float projectileCriticalChance = rangedWeaponData.CriticalChance;
            float projectileDuration = rangedWeaponData.BulletDuration;

            ProjectileInfo projectileInfo = new ProjectileInfo(
                projectileDamage,
                projectilePiercing,
                projectileSpeed,
                projectileSpread,
                projectileKnockback,
                projectileSize,
                projectileCriticalChance,
                projectileDuration);

            for (int i = 0; i < rangedWeaponData.ProjectileAmount; i++)
            {
                Projectile projectile = Instantiate(rangedWeaponData.Projectile);
                projectile.Initialize(projectileInfo, _owner);
                projectile.transform.position = _muzzle.position;
                projectile.transform.rotation = _muzzle.rotation;
            }
            _lastShot = Time.time;
            rangedWeaponData.MagazineAmmo -= 1;

            OnWeaponUsed?.Invoke();
        }
        protected virtual void ProcessReload()
        {
            if (!(_weaponData is RangedWeaponData rangedWeaponData))
                return;

            if (Time.time > _reloadStart + rangedWeaponData.ReloadTime)
            {
                int bulletsToReload = rangedWeaponData.LimitedBullets ? rangedWeaponData.MaxMagazineAmmo - rangedWeaponData.MagazineAmmo : rangedWeaponData.MaxMagazineAmmo;

                if (bulletsToReload >= rangedWeaponData.TotalAmmo && rangedWeaponData.LimitedBullets)
                {
                    bulletsToReload = rangedWeaponData.TotalAmmo;
                    rangedWeaponData.TotalAmmo = 0;
                }

                rangedWeaponData.MagazineAmmo = bulletsToReload;
                _reloading = false;
                OnReloadComplete?.Invoke();
            }
        }
        protected virtual void ReloadWeapon()
        {
            if (!(_weaponData is RangedWeaponData rangedWeaponData))
                return;

            if (rangedWeaponData.TotalAmmo <= 0 && rangedWeaponData.LimitedBullets)
            {
                return;
            }
            if (rangedWeaponData.MagazineAmmo < rangedWeaponData.MaxMagazineAmmo)
            {
                _reloadStart = Time.time;
                _reloading = true;
                OnWeaponReload?.Invoke(_reloadStart, rangedWeaponData.ReloadTime);
            }
        }

    }

}