using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;

namespace Engine247
{
    public class CameraFollow : MonoBehaviour
    {
        [SerializeField] private Transform _followedObject = null;
        [SerializeField] private Camera _controlledCamera = null;
        [SerializeField] private float _followSpeed = 10f;
        [SerializeField] private float _followThreshold = 2f;

        [SerializeField] private float _horizontalMultiplier = .22f;
        [SerializeField] private float _verticalMultiplier = .33f;

        private void OnEnable()
        {
            _controlledCamera = GetComponent<Camera>();
        }
        private void Update()
        {
            if (_followedObject == null || _controlledCamera == null) return;

            FollowObject();
        }

        private void FollowObject()
        {
            Vector2 mousePosition = _controlledCamera.ScreenToWorldPoint(Mouse.current.position.value);
            Vector2 distanceToMouse = mousePosition - (Vector2)_followedObject.position;

            if (distanceToMouse.sqrMagnitude < _followThreshold * _followThreshold) return;

            Vector3 cameraMovement = new Vector3(distanceToMouse.x * _horizontalMultiplier, distanceToMouse.y * _verticalMultiplier, -10);
            transform.DOLocalMove(cameraMovement, .2f);
        }
    }
}
