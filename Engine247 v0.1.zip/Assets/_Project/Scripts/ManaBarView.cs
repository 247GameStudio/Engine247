using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

namespace Engine247
{
    public class ManaBarView : MonoBehaviour
    {
        [SerializeField] private Slider _manaBarSlider = null;
        [SerializeField] private Slider _manaBarBackSlider = null;

        private ManaController _manaController = null;
        private RectTransform _rectTransform = null;

        //The Size in pixels per points of stat
        [SerializeField] private float _rectSizeMultiplier = 2f;
        
        private string tweenID = "mana";
        public void Start()
        {
            tweenID += gameObject.GetInstanceID();
            _rectTransform = GetComponent<RectTransform>();
            _manaBarSlider.maxValue = _manaController.MaxMana;
            _manaBarSlider.value = _manaController.CurrentMana;
            _manaBarBackSlider.maxValue = _manaController.MaxMana;
            _manaBarBackSlider.value = _manaController.CurrentMana;
        }
        public void Initialize(ManaController manaController)
        {
            _manaController = manaController;
            _manaBarSlider.maxValue = _manaController.MaxMana;
            _manaBarSlider.minValue = 0;
            _manaController.OnManaUpdated += OnManaUpdatedHandler;
        }
        public void Deinitialize()
        {
            _manaController.OnManaUpdated -= OnManaUpdatedHandler;
        }

        public void OnManaUpdatedHandler()
        {
            _rectTransform.sizeDelta = new Vector2(_rectSizeMultiplier * _manaController.MaxMana, 3f);
            _manaBarSlider.maxValue = _manaController.MaxMana;
            
            if (_manaBarSlider.value > _manaController.CurrentMana)
            {
                _manaBarSlider.value = _manaController.CurrentMana;
                List<Tween> activeTweens = DOTween.TweensById(tweenID);
                if (activeTweens != null && activeTweens.Count > 0)
                {
                    DOTween.Restart(tweenID, true, 0);
                }
                else
                {
                    Sequence sequence = DOTween.Sequence();
                    sequence.SetId(tweenID);
                    sequence.SetDelay(0.3f);
                    sequence.Append(_manaBarBackSlider.DOValue(_manaController.CurrentMana, .25f));
                }
            }
            else
            {
                _manaBarSlider.value = _manaController.CurrentMana;

                if (_manaBarBackSlider.value < _manaController.CurrentMana)
                    _manaBarBackSlider.value = _manaController.CurrentMana;
            }
        }
    }

}