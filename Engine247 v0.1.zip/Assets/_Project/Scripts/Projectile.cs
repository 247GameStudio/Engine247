using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class Projectile : MonoBehaviour
    {
        private ProjectileInfo _projectileInfo = null;
        private Entity _owner = null;

        private void Start()
        {
            Invoke(nameof(Deinitialize), _projectileInfo.BulletDuration);
            float spread = _projectileInfo.BulletSpread / 2;
            float spreadRotation = Random.Range(-spread, spread);
            transform.Rotate(new Vector3(0, 0, spreadRotation));
        }
        private void FixedUpdate()
        {
            transform.position += transform.right * _projectileInfo.BulletSpeed * Time.deltaTime;
        }

        public void Initialize(ProjectileInfo projectileInfo, Entity owner)
        {
            _projectileInfo = projectileInfo;
            _owner = owner;
            gameObject.SetActive(true);

        }
        public void Deinitialize()
        {
            _projectileInfo = null;
            _owner = null;
            //gameObject.SetActive(false);
            CancelInvoke();
            Destroy(gameObject);
        }

        private void OnTriggerEnter2D(Collider2D collider)
        {
            IDamageable damageable;
            if (!collider.gameObject.TryGetComponent(out damageable)) return;

            //Check critical and calculate damages
            bool isCrit = false;
            if(Random.Range(0, 100) < _projectileInfo.CriticalChance)
            {
                isCrit = true;
            }
            float projectileDamage = isCrit ? _projectileInfo.BulletDamage * 2 : _projectileInfo.BulletDamage * 1;

            float variatedDamage = projectileDamage * Random.Range(0.85f, 1.15f);

            //Process damage reductions
            StatsController entityStats = collider.GetComponent<StatsController>();
            float postReductionDamage = variatedDamage - entityStats.Defense; // variatedDamage - damageReductions

            int finalDamage = Mathf.CeilToInt(Mathf.Max(postReductionDamage, 1));

            HitNumberType hitNumberType = isCrit ? HitNumberType.CritDamage : HitNumberType.Damage;
            HitNumber hitNumber = HitNumberService.Instance.CreateHitNumber(hitNumberType, finalDamage);
            hitNumber.transform.position = transform.position;

            damageable.TakeDamage(finalDamage);

            _projectileInfo.BulletPiercing -= 1;
            if (_projectileInfo.BulletPiercing < 0)
                Deinitialize();
        }

        private void OnDrawGizmos()
        {
            Gizmos.DrawLine(transform.position, transform.position + transform.right * _projectileInfo.BulletSpeed);
        }
    }
}