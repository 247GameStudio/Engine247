using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Engine247
{
    public class ManaController : MonoBehaviour
    {
        public UnityAction OnManaUpdated;

        public int MaxMana { get { return (int)_statsController.MaxMana; } }

        public float CurrentMana
        {
            get => _currentMana;
            set
            {
                _currentMana = value;
                OnManaUpdated?.Invoke();
            }
        }

        [SerializeField] private StatsController _statsController = null;
        [SerializeField] private ManaBarView _manaBarView = null;

        [SerializeField] private float _recoveryWaitCooldown = 0;
        /// <summary>
        /// How many times per second the recovery will be processed.
        /// </summary>
        [SerializeField] private float _recoveryProcessRate = 10;

        private float _currentMana = 0;
        private float _lastTimeSpent = 0;

        public void Initialize()
        {
            CurrentMana = (int)_statsController.MaxMana;
            _statsController.OnStatChanged += OnStatChangedHandler;

            if (_manaBarView != null)
                _manaBarView.Initialize(this);

            InvokeRepeating(nameof(ProcessRecovery), 0, 1 / _recoveryProcessRate);
        }

        public void Deinitialize()
        {
            _statsController.OnStatChanged -= OnStatChangedHandler;

            if (_manaBarView != null)
                _manaBarView.Deinitialize();

            CancelInvoke(nameof(ProcessRecovery));
        }
        private void ProcessRecovery()
        {
            if (Time.time > _lastTimeSpent + _recoveryWaitCooldown)
            {
                Recover(_statsController.ManaRegen / _recoveryProcessRate);
            }
        }
        public void Recover(float amount)
        {
            CurrentMana = Mathf.Min(CurrentMana + amount, MaxMana);
        }
        public bool TrySpend(float amount)
        {
            if (amount > CurrentMana) return false;

            CurrentMana -= amount;
            _lastTimeSpent = Time.time;
            return true;
        }
        private void OnStatChangedHandler(StatType statType)
        {
            if (statType != StatType.MaxMana) return;

            OnManaUpdated?.Invoke();
        }
    }

}