using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

namespace Engine247
{
    public class StaminaBarView : MonoBehaviour
    {
        [SerializeField] private Slider _staminaBarSlider = null;
        [SerializeField] private Slider _staminaBarBackSlider = null;

        private StaminaController _staminaController = null;
        private RectTransform _rectTransform = null;

        private string tweenID = "stamina";

        public void Start()
        {
            tweenID += gameObject.GetInstanceID();
            _rectTransform = GetComponent<RectTransform>();
            _staminaBarSlider.maxValue = _staminaController.MaxStamina;
            _staminaBarSlider.value = _staminaController.CurrentStamina;
            _staminaBarBackSlider.maxValue = _staminaController.MaxStamina;
            _staminaBarBackSlider.value = _staminaController.CurrentStamina;
        }
        public void Initialize(StaminaController healthController)
        {
            _staminaController = healthController;
            _staminaBarSlider.maxValue = _staminaController.MaxStamina;
            _staminaBarSlider.minValue = 0;
            _staminaController.OnStaminaUpdated += OnStaminaUpdatedHandler;
        }
        public void Deinitialize()
        {
            _staminaController.OnStaminaUpdated -= OnStaminaUpdatedHandler;
        }

        public void OnStaminaUpdatedHandler()
        {
            _rectTransform.sizeDelta = new Vector2(2 * _staminaController.MaxStamina, 3f);
            _staminaBarSlider.maxValue = _staminaController.MaxStamina;

            if (_staminaBarSlider.value > _staminaController.CurrentStamina)
            {
                _staminaBarSlider.value = _staminaController.CurrentStamina;
                List<Tween> activeTweens = DOTween.TweensById(tweenID);
                if (activeTweens != null && activeTweens.Count > 0)
                {
                    DOTween.Restart(tweenID, true, 0);
                }
                else
                {
                    Sequence sequence = DOTween.Sequence();
                    sequence.SetId(tweenID);
                    sequence.SetDelay(0.3f);
                    sequence.Append(_staminaBarBackSlider.DOValue(_staminaController.CurrentStamina, .25f));
                }
            }
            else
            {
                _staminaBarSlider.value = _staminaController.CurrentStamina;

                if (_staminaBarBackSlider.value < _staminaController.CurrentStamina)
                    _staminaBarBackSlider.value = _staminaController.CurrentStamina;
            }
        }

    }

}