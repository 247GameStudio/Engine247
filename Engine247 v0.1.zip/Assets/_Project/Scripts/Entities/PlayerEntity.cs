using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engine247
{
    public class PlayerEntity : Entity, IDamageable
    {
        [SerializeField] private StatsController _statsController = null;
        [SerializeField] private HealthController _healthController = null;
        [SerializeField] private StaminaController _staminaController = null;
        [SerializeField] private ManaController _manaController = null;

        protected override void Awake()
        {
            base.Awake();
        }
        private void OnEnable()
        {
            Initialize();
        }
        private void OnDisable()
        {
            Deinitialize();
        }

        public void TakeDamage(int calculatedIncomingDamage)
        {
            if (!Alive) return;

            // Use Calculation class to calculate final damage based on stats!
            int finalDamage = calculatedIncomingDamage - (int)_statsController.DamageReduction;

            _healthController.Damage(finalDamage);
        }

        private void Initialize()
        {
            if (_statsController != null)
            {
                _statsController.Initialize();
            }
            if (_healthController != null)
            {
                _healthController.Initialize();
                _healthController.OnDeath += OnDeathHandler;
            }
            if(_staminaController != null)
            {
                _staminaController.Initialize();
            }
            if(_manaController != null)
            {
                _manaController.Initialize();
            }
        }
        private void Deinitialize()
        {
            if (_statsController != null)
            {
                _statsController.Deinitialize();
            }
            if (_healthController != null)
            {
                _healthController.OnDeath -= OnDeathHandler;
                _healthController.Deinitialize();
            }
            if (_staminaController != null)
            {
                _staminaController.Deinitialize();
            }
            if (_manaController != null)
            {
                _manaController.Deinitialize();
            }
        }

        private void OnDeathHandler()
        {
            _alive = false;
            Destroy(gameObject);
        }
    }
}